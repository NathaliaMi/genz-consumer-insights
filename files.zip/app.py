"""
Gen Z Consumer Insights — Interactive Dashboard
=================================================
Run locally:      streamlit run app.py
Deploy for free:  push this repo to GitHub, then deploy at
                   https://share.streamlit.io (Streamlit Community Cloud)
                   pointing it at app.py. No server config needed.
"""

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from src.data_utils import load_survey, load_benchmarks, trust_gap_summary

# --------------------------------------------------------------------------
# Page config & light styling
# --------------------------------------------------------------------------
st.set_page_config(
    page_title="Gen Z Consumer Insights",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

ACCENT = "#7C3AED"       # violet
ACCENT2 = "#F97316"      # orange
MUTED = "#94A3B8"
PLOTLY_TEMPLATE = "plotly_white"

st.markdown(
    """
    <style>
    .stMetric { background-color: #FAFAFA; padding: 12px 16px; border-radius: 12px; border: 1px solid #eee; }
    div[data-testid="stMetricValue"] { font-size: 1.6rem; }
    .source-tag { color: #94A3B8; font-size: 0.78rem; }
    </style>
    """,
    unsafe_allow_html=True,
)

# --------------------------------------------------------------------------
# Data
# --------------------------------------------------------------------------
survey = load_survey()
benchmarks = load_benchmarks()

st.title("📊 Gen Z Consumer Insights")
st.caption(
    "An interactive read of a 5,000-respondent synthetic Gen Z survey, "
    "cross-checked against ~50 real, cited industry benchmark statistics."
)

# --------------------------------------------------------------------------
# Sidebar filters
# --------------------------------------------------------------------------
st.sidebar.header("🔎 Filter the survey")
st.sidebar.caption("Filters apply to the survey panel only — the Industry Benchmarks tab always shows the full, cited external data.")

age_range = st.sidebar.slider("Age", int(survey.age.min()), int(survey.age.max()), (18, 28))
regions = st.sidebar.multiselect("Region", sorted(survey.region.unique()), default=sorted(survey.region.unique()))
genders = st.sidebar.multiselect("Gender", sorted(survey.gender.unique()), default=sorted(survey.gender.unique()))
employment = st.sidebar.multiselect("Employment", sorted(survey.employment.unique()), default=sorted(survey.employment.unique()))
platforms = st.sidebar.multiselect("Primary platform", sorted(survey.primary_platform.unique()), default=sorted(survey.primary_platform.unique()))

if st.sidebar.button("Reset filters"):
    st.rerun()

f = survey[
    (survey.age.between(*age_range))
    & (survey.region.isin(regions))
    & (survey.gender.isin(genders))
    & (survey.employment.isin(employment))
    & (survey.primary_platform.isin(platforms))
]

st.sidebar.markdown("---")
st.sidebar.metric("Respondents in view", f"{len(f):,}", f"of {len(survey):,} total")

if len(f) == 0:
    st.warning("No respondents match these filters — widen your selection in the sidebar.")
    st.stop()

# --------------------------------------------------------------------------
# Tabs
# --------------------------------------------------------------------------
tab_overview, tab_money, tab_media, tab_values, tab_benchmarks, tab_findings = st.tabs(
    ["📌 Overview", "💳 Money & Spending", "📱 Media & Screen Time",
     "🧭 Values & Trust", "🌍 Industry Benchmarks", "🔍 Findings & Anomalies"]
)

# --------------------------------------------------------------------------
# TAB 1 — Overview
# --------------------------------------------------------------------------
with tab_overview:
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Avg. annual income", f"${f.annual_income_usd.mean():,.0f}")
    c2.metric("Avg. daily screen time", f"{f.daily_screen_hours.mean():.1f} hrs")
    c3.metric("Uses Buy Now, Pay Later", f"{(f.uses_buy_now_pay_later.eq('Yes').mean()*100):.0f}%")
    c4.metric("Avg. monthly discretionary spend", f"${f.monthly_discretionary_usd.mean():,.0f}")

    col1, col2 = st.columns(2)
    with col1:
        st.subheader("Who's in view")
        dims = st.selectbox("Break down by", ["region", "gender", "employment", "education", "ethnicity"], key="ov_dim")
        counts = f[dims].value_counts().reset_index()
        counts.columns = [dims, "count"]
        fig = px.bar(counts, x=dims, y="count", color=dims, template=PLOTLY_TEMPLATE,
                     color_discrete_sequence=px.colors.sequential.Purples_r)
        fig.update_layout(showlegend=False, height=380)
        st.plotly_chart(fig, use_container_width=True)

    with col2:
        st.subheader("Primary platform mix")
        pf = f.primary_platform.value_counts().reset_index()
        pf.columns = ["platform", "count"]
        fig = px.pie(pf, names="platform", values="count", hole=0.5, template=PLOTLY_TEMPLATE,
                     color_discrete_sequence=px.colors.sequential.Purples_r)
        fig.update_layout(height=380)
        st.plotly_chart(fig, use_container_width=True)

    st.info(
        "💡 **Read this first:** across every slice we tested, the attitudinal survey variables "
        "(trust, values, screen time) barely move by demographic — see the **Findings & Anomalies** "
        "tab for why that itself is the headline finding, not a bug."
    )

# --------------------------------------------------------------------------
# TAB 2 — Money & Spending
# --------------------------------------------------------------------------
with tab_money:
    col1, col2 = st.columns(2)
    with col1:
        st.subheader("Income vs. discretionary spend")
        sample = f.sample(min(1200, len(f)), random_state=42)
        fig = px.scatter(
            sample, x="annual_income_usd", y="monthly_discretionary_usd",
            color="employment", opacity=0.55, template=PLOTLY_TEMPLATE,
            labels={"annual_income_usd": "Annual income ($)", "monthly_discretionary_usd": "Monthly discretionary spend ($)"},
            color_discrete_sequence=px.colors.qualitative.Set2,
        )
        fig.update_layout(height=420)
        st.plotly_chart(fig, use_container_width=True)
        st.caption(f"Correlation (income ↔ discretionary spend): **r = {f.annual_income_usd.corr(f.monthly_discretionary_usd):.2f}** — "
                   "discretionary spend tracks income almost linearly, at a remarkably steady "
                   f"**~{f.discretionary_pct_of_income.mean():.0f}% of income** regardless of employment type.")

    with col2:
        st.subheader("BNPL adoption by income quartile")
        bnpl = pd.crosstab(f.income_quartile, f.uses_buy_now_pay_later, normalize="index") * 100
        bnpl = bnpl.reset_index().melt(id_vars="income_quartile", var_name="uses_bnpl", value_name="pct")
        fig = px.bar(bnpl[bnpl.uses_bnpl == "Yes"], x="income_quartile", y="pct", template=PLOTLY_TEMPLATE,
                     color_discrete_sequence=[ACCENT], text_auto=".1f")
        fig.update_layout(yaxis_title="% using BNPL", xaxis_title="Income quartile", height=420)
        st.plotly_chart(fig, use_container_width=True)
        st.caption("BNPL adoption is essentially flat across income quartiles (~41–44%) — in this "
                   "panel it behaves like a generational default payment habit, not a low-income coping tool.")

    st.subheader("Preferred shopping channel")
    ch = f.preferred_shopping_channel.value_counts(normalize=True).mul(100).reset_index()
    ch.columns = ["channel", "pct"]
    fig = px.bar(ch.sort_values("pct"), x="pct", y="channel", orientation="h", template=PLOTLY_TEMPLATE,
                 color_discrete_sequence=[ACCENT2], text_auto=".1f")
    fig.update_layout(xaxis_title="% of respondents", yaxis_title="", height=320)
    st.plotly_chart(fig, use_container_width=True)

# --------------------------------------------------------------------------
# TAB 3 — Media & Screen Time
# --------------------------------------------------------------------------
with tab_media:
    col1, col2 = st.columns(2)
    with col1:
        st.subheader("Daily screen time distribution")
        fig = px.histogram(f, x="daily_screen_hours", nbins=40, template=PLOTLY_TEMPLATE,
                            color_discrete_sequence=[ACCENT])
        fig.add_vline(x=f.daily_screen_hours.mean(), line_dash="dash", line_color=ACCENT2,
                      annotation_text=f"mean = {f.daily_screen_hours.mean():.1f}h")
        fig.update_layout(height=400, xaxis_title="Hours / day", yaxis_title="Respondents")
        st.plotly_chart(fig, use_container_width=True)

    with col2:
        st.subheader("Avg. screen time by primary platform")
        st_by_platform = f.groupby("primary_platform")["daily_screen_hours"].mean().sort_values().reset_index()
        fig = px.bar(st_by_platform, x="daily_screen_hours", y="primary_platform", orientation="h",
                     template=PLOTLY_TEMPLATE, color_discrete_sequence=[ACCENT], text_auto=".2f")
        fig.update_layout(height=400, xaxis_title="Avg. daily screen time (hrs)", yaxis_title="")
        st.plotly_chart(fig, use_container_width=True)
        st.caption("Note the tight range (~5.9–6.2h) — in this panel, self-reported screen time barely "
                   "varies by which app someone names as primary.")

    st.subheader("How brands get discovered")
    bd = f.brand_discovery_channel.value_counts(normalize=True).mul(100).reset_index()
    bd.columns = ["channel", "pct"]
    fig = px.bar(bd.sort_values("pct"), x="pct", y="channel", orientation="h", template=PLOTLY_TEMPLATE,
                 color_discrete_sequence=[ACCENT], text_auto=".1f")
    fig.update_layout(xaxis_title="% of respondents", yaxis_title="", height=320)
    st.plotly_chart(fig, use_container_width=True)

# --------------------------------------------------------------------------
# TAB 4 — Values & Trust
# --------------------------------------------------------------------------
with tab_values:
    col1, col2 = st.columns(2)
    with col1:
        st.subheader("The trust gap: ads vs. influencers")
        tg = trust_gap_summary(f)
        fig = go.Figure(go.Bar(
            x=tg.avg_trust_1to5, y=tg.channel, orientation="h",
            marker_color=[MUTED, ACCENT], text=tg.avg_trust_1to5.round(2), textposition="outside",
        ))
        fig.update_layout(template=PLOTLY_TEMPLATE, xaxis_title="Avg. trust (1–5 scale)", xaxis_range=[0, 5], height=280)
        st.plotly_chart(fig, use_container_width=True)
        st.caption("This ~1-point gap holds across every region, gender, and income group we sliced — "
                   "it reads as a baseline generational stance, not a niche segment's opinion.")

    with col2:
        st.subheader("Sustainability & brand-authenticity values")
        vals = f[["val_sustainability_1to5", "val_brand_authenticity_1to5"]].melt(var_name="value", value_name="score")
        vals["value"] = vals["value"].map({
            "val_sustainability_1to5": "Sustainability matters",
            "val_brand_authenticity_1to5": "Brand authenticity matters",
        })
        fig = px.histogram(vals, x="score", color="value", barmode="group", nbins=5, template=PLOTLY_TEMPLATE,
                            color_discrete_sequence=[ACCENT, ACCENT2])
        fig.update_layout(height=280, xaxis_title="Score (1–5)", yaxis_title="Respondents")
        st.plotly_chart(fig, use_container_width=True)

    st.subheader("Trust in influencers by primary platform")
    tp = f.groupby("primary_platform")["trust_influencers_1to5"].mean().sort_values().reset_index()
    fig = px.bar(tp, x="trust_influencers_1to5", y="primary_platform", orientation="h", template=PLOTLY_TEMPLATE,
                 color_discrete_sequence=[ACCENT], text_auto=".2f")
    fig.update_layout(xaxis_title="Avg. trust in influencers (1–5)", yaxis_title="", xaxis_range=[0, 5], height=320)
    st.plotly_chart(fig, use_container_width=True)

# --------------------------------------------------------------------------
# TAB 5 — Industry Benchmarks (external, cited data — always unfiltered)
# --------------------------------------------------------------------------
with tab_benchmarks:
    st.subheader("🌍 Real-world benchmark statistics (cited, not survey-derived)")
    st.caption(
        "These ~50 figures come from `data/industry_benchmarks.csv` — third-party research "
        "(Bank of America Institute, PwC, Circana, Experian, NRF, and others). They give the "
        "5,000-respondent survey above a real-world backdrop. See the README for direct links "
        "to primary sources."
    )
    cats = sorted(benchmarks.category.unique())
    pick = st.multiselect("Category", cats, default=cats)
    bshow = benchmarks[benchmarks.category.isin(pick)].copy()
    bshow["value"] = bshow.apply(lambda r: f"{r['value']:g}{r['unit'] if r['unit'] in ('%','') else ' ' + r['unit']}"
                                  if pd.notna(r["value"]) else "—", axis=1)
    st.dataframe(
        bshow[["category", "metric", "value", "population", "source", "year", "notes"]],
        use_container_width=True, height=520, hide_index=True,
    )

# --------------------------------------------------------------------------
# TAB 6 — Findings & Anomalies (narrative)
# --------------------------------------------------------------------------
with tab_findings:
    st.markdown(
        """
### 🔍 Key findings

1. **The ad-trust / influencer-trust gap is the sharpest, most consistent signal in the survey.**
   Traditional ads average **2.33 / 5** trust vs. **3.39 / 5** for influencers — roughly a full point apart —
   and that gap barely shifts across region, gender, income, or platform. It looks like a generational
   baseline rather than a niche attitude.

2. **Discretionary spending is a near-fixed share of income (~22%), regardless of employment status.**
   Unemployed, part-time, gig, and full-time respondents all land within ~0.4 percentage points of each
   other. Income level predicts spend almost perfectly (r ≈ 0.88); *how* someone earns it barely matters.

3. **BNPL (Buy Now, Pay Later) adoption (~42%) is flat across income quartiles.**
   The lowest earners aren't meaningfully more likely to use BNPL than the highest earners in this panel —
   it behaves like a payment-method preference woven across the income spectrum, not purely a
   credit-access workaround.

4. **Platform choice barely moves daily screen time.** Whether someone names TikTok, Instagram, Reddit,
   or YouTube as their primary platform, average daily screen time sits in a narrow **5.9–6.2 hour** band.

### ⚠️ Anomalies & data-quality notes worth flagging

- **Attitudinal variables show almost zero correlation with demographics or with each other**
  (correlation coefficients mostly under 0.05, aside from the income↔spend relationship). For a
  portfolio-style project, the honest read is that this survey's Likert-scale and categorical fields
  behave like independently-drawn distributions layered on top of demographics — useful for practicing
  EDA, filtering, and visualization, but **not a substitute for a real, weighted panel** when the
  stakes are a real business decision. We're flagging this transparently rather than overstating
  causal "Gen Z segment X thinks Y" claims the data can't actually support.
- **9 respondents report 3+ standard deviations of daily screen time (up to 16 hrs/day)** — plausible
  for a genuinely online-heavy respondent, but worth a sanity check (device double-counting, always-on
  background use) before using this column for anything sensitive.
- **The gender categories "Non-binary" and "Prefer not to say" have small sample sizes** (92 and 45
  respondents respectively) — read differences involving those groups as directional, not statistically
  robust.

### 🌐 What this could mean in a broader context

The survey's two clearest signals — **low trust in traditional advertising** and **steady,
income-proportional (not identity-proportional) spending** — line up with what independent, real-world
research is currently finding about Gen Z as a cohort, even though this survey is synthetic:

- Gen Z's **global spending power is projected to roughly quadruple**, from an estimated **$2.7 trillion
  in 2024 to $12.6 trillion by 2030**, according to the Bank of America Institute's *"Gen Z: A new
  economic force"* report — even as many individuals in the cohort report real budget pressure
  ([Bank of America Institute, 2025](https://institute.bankofamerica.com/economic-insights/genz-new-economic-force.html)).
- That pressure shows up in actual transaction data: PwC's analysis of roughly a million consumer
  transactions found **U.S. Gen Z spending fell about 13% between January and April 2025**, concentrated
  in apparel, accessories, and electronics — read by PwC as a shift toward value-consciousness rather
  than simple frugality
  ([PwC, "Gen Z Consumer Trends," 2025](https://www.pwc.com/us/en/industries/consumer-markets/library/gen-z-consumer-trends.html)).
- Gaming — often assumed to be recession-proof for a young, online-first generation — saw an even
  sharper pullback: Circana data reported by the *Wall Street Journal* found **weekly video-game
  spending among 18–24-year-olds down roughly 25% year-over-year**, a far steeper drop than the
  under-5% decline seen in older age groups
  ([reported via PC Gamer, 2025](https://www.pcgamer.com/gaming-industry/new-study-shows-that-gen-z-is-spending-way-less-money-on-videogames-than-older-gamers/)).
- Meanwhile, credit behavior stays comparatively conservative: Experian puts **Gen Z's average credit
  card balance at about $3,493** as of mid-2025 — the lowest of any adult generation, though it's growing
  faster year-over-year than older cohorts' balances
  ([Experian, "Average Credit Card Debt by Age," 2025](https://www.experian.com/blogs/ask-experian/research/credit-card-debt-by-age/)).
- And the survey's influencer-trust finding tracks with retail industry research: a 2025 ICSC report
  covered by Retail Dive found **85% of Gen Z say social media influences their purchasing decisions** —
  well ahead of traditional advertising channels
  ([Retail Dive, 2025](https://www.retaildive.com/news/generation-z-social-media-influence-shopping-behavior-purchases-tiktok-instagram/652576/)).

**Taken together:** the picture that emerges — from both this survey and the cited external research —
is a generation with genuinely large aggregate spending power and a structurally low baseline of trust
in traditional marketing, but one that is currently spending more cautiously in practice than its
long-run purchasing power would suggest. For brands and researchers, that combination argues for
earning attention through credible, peer- and creator-level channels rather than traditional
advertising, while not assuming today's cautious spending is Gen Z's permanent ceiling.

*Full source list with links is in the README and in `data/industry_benchmarks.csv`.*
        """
    )

st.markdown("---")
st.caption(
    "Built with Streamlit + Plotly. Survey data (5,000 rows) is synthetic and included for "
    "portfolio/demo purposes; benchmark data is real and cited — see README.md for full sources."
)
